<div id="footer">
  <h2 style="text-align:center; padding-top:30px">&copy; 2016 - <?php echo date('Y');?> by www.metrixcode.com</h2>
  </div>
  
</div><!-- /.main_wrapper-->

<!-- End Main container starts here --->

</body>

</html>